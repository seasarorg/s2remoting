package examples.communication.client;

import org.seasar.framework.container.S2Container;
import org.seasar.framework.container.factory.SingletonS2ContainerFactory;

import examples.communication.service.HelloService;

public class HelloClient {

    private HelloService service;

    public void execute() {
        System.out.println(this.service.say());
    }

    public static void main(String[] args) throws Exception {

        // S2Container�̏�����
        SingletonS2ContainerFactory.init();
        S2Container container = SingletonS2ContainerFactory.getContainer();

        HelloClient client = new HelloClient();
        client.service = (HelloService) container.getComponent(HelloService.class);
        client.execute();

        SingletonS2ContainerFactory.destroy();
    }

}
