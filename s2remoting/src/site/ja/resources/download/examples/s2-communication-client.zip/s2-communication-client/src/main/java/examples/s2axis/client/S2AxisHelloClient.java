package examples.s2axis.client;

import org.seasar.framework.container.S2Container;
import org.seasar.framework.container.factory.SingletonS2ContainerFactory;

import examples.communication.service.HelloService;

public class S2AxisHelloClient {

    private HelloService service;

    public void execute() {
        System.out.println("[S2Axis]" + this.service.say());
    }

    public static void main(String[] args) throws Exception {

        S2AxisHelloClient client = new S2AxisHelloClient();

        SingletonS2ContainerFactory.setConfigPath("examples/s2axis/client/s2axis-client.dicon");
        
        SingletonS2ContainerFactory.init();
        S2Container container = SingletonS2ContainerFactory.getContainer();

        client.service = (HelloService) container.getComponent(HelloService.class);
        client.execute();

        SingletonS2ContainerFactory.destroy();
    }

}
