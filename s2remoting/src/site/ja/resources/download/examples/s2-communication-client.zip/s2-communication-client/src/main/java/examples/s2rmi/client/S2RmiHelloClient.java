package examples.s2rmi.client;

import org.seasar.framework.container.S2Container;
import org.seasar.framework.container.factory.SingletonS2ContainerFactory;

import examples.communication.service.HelloService;

public class S2RmiHelloClient {

    private HelloService service;

    public void execute() {
        System.out.println("[S2RMI]" + this.service.say());
    }

    public static void main(String[] args) throws Exception {

        S2RmiHelloClient client = new S2RmiHelloClient();

        // SMART deploy ���g��Ȃ��ꍇ�̎w��
        SingletonS2ContainerFactory.setConfigPath("examples/s2rmi/client/s2rmi-client.dicon");

        SingletonS2ContainerFactory.init();
        S2Container container = SingletonS2ContainerFactory.getContainer();

        client.service = (HelloService) container.getComponent(HelloService.class);
        client.execute();

        SingletonS2ContainerFactory.destroy();
    }

}
